# Developing a API With NodeJs, ExpressJs, Swagger and TypeScript using test-driven development (TDD).

1. Open project folder
2. run this command to install dependencies- `npm install`
3. run this command to Compile - `npm run build`
4. run this command to Compile assets - `gulp assets`
5. run this command to Run the development server - `npm start`
6. run this command to Test - `npm test`

#additional technologies used for

1. used Gulp for automating transpilation, it means to transpile typescript to javascript 
2. Express for creating HTTP server and hosts the app in browser
3. used Mocha and Chai for creating automated unit tests
4. User swagger for creating UI for endpoints

# once running our api, we can see all endpoints in http://localhost:3000/swagger-doc/
