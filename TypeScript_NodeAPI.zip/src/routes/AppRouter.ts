import {Router, Request, Response, NextFunction} from 'express';
const countries = require('../countryData');

export class AppRouter {
  router: Router

  /**
   * Initialize the AppRouter in constructor
   */
  constructor() {
    this.router = Router();
    this.init();
  }

  /**
   * GET all countries.
   */
  public getAll(req: Request, res: Response, next: NextFunction) {
    res.send(countries);
  }

  /**
   * GET one country by id
   */
  public getCountryById(req: Request, res: Response, next: NextFunction) {
    let query = parseInt(req.params.id);
    let country = countries.find(country => country.id === query);
    if (country) {
      res.status(200)
        .send({
          message: 'Success',
          status: res.status,
          country
        });
    }
    else {
      res.status(404)
        .send({
          message: 'No data found with the given id.',
          status: res.status
        });
    }
  }
  
  //initialization
  init() {
    this.router.get('/', this.getAll);
    this.router.get('/:id', this.getCountryById);
  }

}

// Create the instance for AppRouter, and export 
const appRoutes = new AppRouter();
appRoutes.init();

export default appRoutes.router;
