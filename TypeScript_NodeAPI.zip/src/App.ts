import * as path from 'path';
import * as express from 'express';
import * as logger from 'morgan';
import * as bodyParser from 'body-parser';
import * as swaggerUi from "swagger-ui-express";
const swaggerDoc = require('./swagger.json');

import AppRouter from './routes/AppRouter';

// to Create and configure an ExpressJS web server.
class App {

  // add ref to Express instance
  public express: express.Application;

  //Run configuration methods on the Express instance.
  constructor() {
    this.express = express();
    this.middleware();
    this.routes();
  }

  // Configure Express middleware.
  private middleware(): void {
    this.express.use(logger('dev'));
    this.express.use(bodyParser.json());
    this.express.use(bodyParser.urlencoded({ extended: false }));
  }

  // Configure API endpoints.
  private routes(): void {
   
    // API endpoints
    let router = express.Router();
    // placeholder route handler
    router.get('/', (req, res, next) => {
      res.json({
        message: 'API works!'
      });
    });
    this.express.use('/', router);
    this.express.use('/api/v1/countries', AppRouter);
    router.use("/swagger-doc", swaggerUi.serve, swaggerUi.setup(swaggerDoc));
  }

}

export default new App().express;
